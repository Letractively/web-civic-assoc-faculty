var searchData=
[
  ['query',['query',['../class_c_i___d_b__driver.html#af987e82e6283e31a44db93d51558710d',1,'CI_DB_driver']]]
];
